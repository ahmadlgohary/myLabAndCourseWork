/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Ahmad El-Gohary
 */
/*package coe318.lab7;

public class Voltage {
    private static int numberOfSources=0;
    private double voltage;
    private Node node1, node2, temp;
    private int sourceID;
    
    public Voltage(Node node1, Node node2, double voltage){
        if ((node1 == null) || (node2 == null)) {
            throw new IllegalArgumentException("Invalid Both nodes must exist");
        }
        if ((node1 == node2 )) {
            throw new IllegalArgumentException("Invalid Both nodes should not be equal");
        }

        this.voltage=voltage;
        this.node1=node1;
        this.node2=node2;
        numberOfSources++;
        sourceID=numberOfSources;
    
    }
    public void flip(){
        this.voltage=-voltage;
        this.temp=node1;
        this.node1=node2;
        this.node2=temp;
    }
    public String toString(){
        return "V" + sourceID + " " + node1.getNodeID() + " " + node2.getNodeID() + " DC " + voltage + "\n";
    }
    
}
*/