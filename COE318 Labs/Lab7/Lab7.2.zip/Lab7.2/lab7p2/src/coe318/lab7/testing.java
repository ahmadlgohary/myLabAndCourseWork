/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coe318.lab7;

/**
 *
 * @author Ahmad El-Gohary
 */
public class testing {
     public static void main(String[] args){
        Circuit c1 = Circuit.getInstance();
        // build circuit
        
        Node node1 = new Node();
        Node node2 = new Node();
        Node node3 = new Node();
       
        //declare nodes
        Compounent r1 = new Compounent ("r", node1, node2, 5);
        Compounent r2 = new Compounent ("r", node2, node3, 10);
        Compounent r3 = new Compounent ("r", node1, node3, 15);
        Compounent c = new Compounent  ("v", node1, node2, 5);
        //declare resistors
        
        c1.add(r1);
        c1.add(r2);
        c1.add(r3);
        c1.add(c);
        
        //add resistors to ciruit
        
        System.out.println(node1);
        System.out.println(node2);
        System.out.println(node3);
        //prints node id's
        
        System.out.println(c1);
        // print circuit 
        c.flip();
        //v.flip();
        System.out.println(c1);
    }
    
}

