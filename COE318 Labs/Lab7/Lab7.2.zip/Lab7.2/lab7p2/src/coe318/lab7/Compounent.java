/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coe318.lab7;

/**
 *
 * @author Ahmad El-Gohary
 */
public class Compounent {
    private static int numberOfSources=0, numberOfResistors = 0;
    private double voltage, resistance;
    private Node node1, node2, temp;
    private int resistorID, sourceID;
    private String type;
     public Compounent(String type, Node node1, Node node2, double value){
        if ((node1 == null) || (node2 == null)) {
            throw new IllegalArgumentException("Invalid Both nodes must exist");
        }
        if ((node1.getNodeID() == node2.getNodeID() )) {
            throw new IllegalArgumentException("Invalid Both nodes should not be equal");
        }
        if(type.equals("v") || type.equals("V")){
        this.type=type;
        this.voltage=value;
        this.node1=node1;
        this.node2=node2;
        numberOfSources++;
        sourceID=numberOfSources;    
        }
        else if (type.equals("r") || type.equals("R")){
        this.type=type;
        this.resistance=value;
        if (value <= 0){
            throw new IllegalArgumentException("resistance must be a positive number");
        }
        this.node1 = node1;
        this.node2 = node2;
        numberOfResistors++;
        resistorID = numberOfResistors;
        }
        else{
            throw new IllegalArgumentException("Invalid Compounent: Compounent must be either a Resistor or a Voltage Source ");
        }
        
     }
     public void flip(){
        this.voltage=-voltage;
        this.temp=node1;
        this.node1=node2;
        this.node2=temp;
     }
     public Node[] getNodes(){
        Node[] nodes = new Node[2];
               nodes[0] = node1;
               nodes[1] = node2;
        return nodes;
    }
     
    public int getResistorID() {
        return resistorID;
    }
    public int getSourceID() {
        return sourceID;
    }
     public String toString(){
         if (type.equals("r") || type.equals("R")){
         
        return "R" + resistorID + " " + node1.getNodeID() + " " + node2.getNodeID() + " " + resistance + " ohms\n";
        }
        if(type.equals("v") || type.equals("V")){ 
            
        return "V" + sourceID + " " + node1.getNodeID() + " " + node2.getNodeID() + " DC " + voltage + "V\n";
    
         }
        return "";
    }

}
