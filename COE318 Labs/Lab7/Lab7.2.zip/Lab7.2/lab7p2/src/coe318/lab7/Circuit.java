/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coe318.lab7;

import java.util.ArrayList;

/**
 *
 * @author Ahmad El-Gohary
 */
public class Circuit {
    
    private static Circuit instance = null; 
    
    public static Circuit getInstance() {
    if (instance == null) { 
        instance = new Circuit();
    }
    return instance;
}
    
    private ArrayList<Compounent> Compounents = new ArrayList<Compounent>();


    private Circuit() {}
    
        public void add(Compounent c){
        Compounents.add(c);
}

        
        public String toString(){
        String Comp2String="";

        for (Compounent Comp : Compounents){
            Comp2String += Comp.toString();
        }

        return Comp2String + "\n";
    }
}

