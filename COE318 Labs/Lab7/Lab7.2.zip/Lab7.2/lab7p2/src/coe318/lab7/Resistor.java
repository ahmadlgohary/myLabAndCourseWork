/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author Ahmad El-Gohary
 */
/*package coe318.lab7;
public class Resistor {
    private static int numberOfResistors = 0;
    private double resistance;
    private Node node1, node2;
    private int resistorID;
    
    public Resistor(double resistance, Node node1, Node node2){
    if (resistance <= 0){
            throw new IllegalArgumentException("resistance must be a positive number");
        }
        if ((node1 == null) || (node2 == null)) {
            throw new IllegalArgumentException("Invalid Both nodes must exist");
        }
        if ((node1 == node2 )) {
            throw new IllegalArgumentException("Invalid Both nodes should not be equal");
        }
        numberOfResistors++;
        resistorID = numberOfResistors;
        this.resistance = resistance;
        this.node1 = node1;
        this.node2 = node2;
    }
public Node[] getNodes(){
        Node[] nodes = new Node[2];
               nodes[0] = node1;
               nodes[1] = node2;
        return nodes;
    }
      public String toString(){
        return "R" + resistorID + " " + node1.getNodeID() + " " + node2.getNodeID() + " " + resistance + " ohms\n";
    }
}*/