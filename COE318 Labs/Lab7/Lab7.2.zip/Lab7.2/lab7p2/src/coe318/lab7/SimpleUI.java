/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Ahmad El-Gohary
 */
package coe318.lab7;
import java.util.ArrayList;
import java.util.Scanner;


public class SimpleUI implements UI {
    public static void main(String[] args)
    {
        SimpleUI UI = new SimpleUI();
        UI.start();
    }
    private String input;
    private ArrayList<Compounent> comps = new ArrayList<>();
    private final Scanner user = new Scanner(System.in);
    
public void start()
    {
        display();
        run();
    }

   public void spice()
   {
       for(Compounent c : comps){
            System.out.print(c);
       }
    }
   
   public void end()
   {
       System.out.println("Your final circuit is: ");
       spice();
       System.out.println("All done");
   }

   public void display()
    {
        System.out.println(" Insert compounets in the form of:");
        System.out.println("'Type(r or v)' 'first node' 'second node' 'Value'");
        System.out.println(" To flip a component type in 'flip' + the compounet's name");
    }
   public void run()
    {
   
        while(true){
            input = user.nextLine().trim();
            if(input.toLowerCase().equals("end")) 
            {
                end();
                break;
            }
            else if(input.toLowerCase().equals("spice"))
            {
                spice();
            }
            else if(input.toLowerCase().contains("flip"))
            {
                 String[] flip = input.split(" ");
                 int a;
                 String b;
                 for(int i=0; i<2; i++){
                 if(!flip[i].equals("flip")){
                  //System.out.println(flip[i]);
                 b = String.valueOf(flip[i].charAt(0));
                 a = Integer.parseInt(String.valueOf(flip[i].replaceFirst(b,"")));
                    
                 
                    for(i=0; i<comps.size(); i++){
                        if( b.equals("v") && a ==comps.get(i).getSourceID()){
                            comps.get(i).flip();
                           }
                        else if (b.equals("r") && a ==comps.get(i).getResistorID()){
                            comps.get(i).flip();
                            }
                        }
                    }
                }
            }
            else
            {
              String[] chara = input.split(" ");
                if(chara.length != 4)
                {
                    System.out.println("Error");
                    display();
                    }
                else{
                        
                        Node node1 = new Node();
                        Node node2 = new Node();
                        double value;
                        node1.setNodeID(Integer.parseInt(chara[1]));
                        node2.setNodeID(Integer.parseInt(chara[2]));
                        value = Double.parseDouble(chara[3]);
                        Compounent x = new Compounent(String.valueOf(input.charAt(0)), node1, node2, value);
                        comps.add(x);
                        
                    
                }
            }
        }
    }
}


