/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coe318.lab7;

/**
 *
 * @author Ahmad El-Gohary
 */
public class Node {
    private static int numberOfNodes = 0;
    private int nodeID;
    public Node(){
        numberOfNodes++;
        nodeID = numberOfNodes;
    }

    public int getNodeID() {
        return nodeID;
    }

    public void setNodeID(int nodeID) {
        this.nodeID = nodeID;
    }
     public String toString(){
        return "node" + nodeID;
    }
}

