#include <stdio.h>

int main(void) {
printf(" X O X\n X X O\n O O X\n");
  return 0;
}