#include <stdio.h>

int
 /*was inx*/
main (void) {	
  int a = 3, b = 4, e;
  /*comma , instead of a semi column ; after "a=3"*/
	double f = 4, c, d;
  /*was Double with a capital d. C is cases sensitive*/
	d = a + b;
	c = a/(f - b);
	printf("The value of d is %f\n", d);
  /*missimg quotations and proper place holder and a semi column after the commad*/
	return (0);
}