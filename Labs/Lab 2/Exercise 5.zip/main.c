#include <stdio.h> 
#include <math.h>

int main(void) {
float a, b, pi;
double A;
pi = 3.1415;
printf("Enter the long radius of your ellipse\n");
scanf("%f", &a);
printf("Enter the short radius of your ellipse\n");
scanf("%f", &b);
A = 2*pi*sqrt((a*a+b*b)/2);
printf("your number is %f", A);
return(0);
}