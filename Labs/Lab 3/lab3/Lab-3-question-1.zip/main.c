#include <stdio.h>
#include <math.h>

int main(void) {
  double a, b, c, d, e, f, g, h;
  printf("Insert 4 diffrent numbers\n");
  scanf("%lf %lf %lf %lf", &a, &b, &c, &d);
  e = a + b + c + d;
  f = (a+b)-(c+d);
  g = a*a + b*b + c*c + d*d;
  h = sqrt(g)/e;
  printf("Sum of the four values is: %f\n", e);
  printf("The sum of the first two numbers minus the sum of the last two %f\n", f);
  printf("The sum of the squares of the four numbers %f\n", g);
  printf("The square root the sum of squares of the 4 numbers divided by their sum is %.2lf\n", h);
  return 0;
}