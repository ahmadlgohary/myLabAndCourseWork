#include <stdio.h>

int main(void) {
  int a, b;
  printf("insert 2 integers\n");
  scanf("%d %d", &a, &b );
  if (a == b){
  printf("%d\n", 3*(a+b));}
  if (a != b){
    printf("%d", (a+b));}
  return 0;
}