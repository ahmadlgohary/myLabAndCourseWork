#include <stdio.h>
#include <math.h>

int main(void) {
  double raduis, pi = 3.1415, V;
  printf("this program calculates a volume of a sphere with a given raduis\ninsert raduis of sphere\n");
scanf("%lf", &raduis);
V = 4*pow(raduis, 3)*pi/3.0;
printf("The volume of your sphere is: %f", V);
  return 0;
}