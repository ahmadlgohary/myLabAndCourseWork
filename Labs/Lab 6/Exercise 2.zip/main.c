#include <stdio.h>
#include <math.h>
 int quad(double a, double b, double c){
   double x1, x2;
 if (b*b-4*a*c>=0)
    x1= (-b+sqrt(b*b-4*a*c))/(2.0*a);
     x2= (-b-sqrt(b*b-4*a*c))/(2.0*a);
 else 
x1= -b/(2*a) '-i' sqrt(-b*b+4*a*c)/(2.0*a*1.0);
x2= -b/(2*a) '+i' sqrt(-b*b+4*a*c)/(2.0*a*1.0);
 return (printf("x1 is %6.3lf.\nx2 is %6.3lf.", x1, x2));
}

int main(void) {
  double a, b, c; 
  double x1, x2;
  printf("enter the coefficent of x^2 x^1 and x^0 respectivley \n");
  scanf("%lf %lf %lf", &a, &b, &c);
x1= quad(a,b,c); 
  return 0;
}




/* * relates to a pointer which is a variable which stores the address of another variable & is the address of the variable, the location of which the value of the variable is stored into in the ram*/