#include <stdio.h>

int main(void) {
  double a, b, c, d, e, f, g, h;
  a = 100, b = 200, c = 400, d = 800;
  a = a*1.094;
  printf("           | in yard is: |  in miles is: \n");
  printf("100 meters | %f  |", a);
  a = a*0.0006215;
  printf("  %f\n", a);

  b = b*1.094;
  printf("200 meters | %f  |", b);
  b = b*0.0006215;
  printf("  %f\n", b);
  

  c = c*1.094;
  printf("400 meters | %f  |", c);
  c = c*0.0006215;
  printf("  %f\n", c);
  

  d = d*1.094;
  printf("100 meters | %f  |", d);
  d = d*0.0006215;
  printf("  %f\n", d);
  
}