#include <stdio.h>

int main(void) {
double a, b, c;
  printf("this program gives you the third angle of a triangle wen given 2 angles\ninsert 2 angles of your triangle\n");
  scanf("%lf %lf", &a, &b);
  c = 180 - a - b;
  printf("the third angle is: %f",c);
  return 0;
}