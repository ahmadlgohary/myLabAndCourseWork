#include <stdio.h>

int main(void) {
  int a, b, c;
  printf("insert 3 diffrent integers\n");
  scanf("%d %d %d",&a, &b, &c);
  printf("The integers from largest to smallest are:\n");
    if (a>b) {
        if (b<c){
        printf("%d %d %d", c,b,a);
        }
 
        else if (a<c){
        printf("%d %d %d", b,c,a);
        }
        else {
        printf("%d %d %d", b,a,c);
        } 
        if (b>c){
        printf("%d %d %d", a,b,c);
        }
        else if (b<c){
        printf("%d %d %d", a,c,b);
        }
        else {
        printf("%d %d %d", c,a,b);
        }
       }
 
   
  return 0;
  }