#include <stdio.h>
#define SIZE_OF_ARRAY 10
#define TRUE 1
#define FALSE 0
#define NOT_FOUND -1 

// Declare function binary_srch 
int binary_srch(const int search_array[], int target, int size);

int main (void) {

    int array[SIZE_OF_ARRAY]; 
    int target, index;

    // For loop to enter numbers into array
    for (int i = 0; i < SIZE_OF_ARRAY; i++) {
        printf("Enter an integer number for the array at index %d: ", i);
        scanf("%d", &array[i]);
    }

    // Ask user the what the target element is
    printf("What is the target element you want to find in the array? ");
    scanf("%d", &target);

    // call function to search for a target in an array with a large number of ints
    index = binary_srch(array, target, SIZE_OF_ARRAY);

    if (index != NOT_FOUND) {
      printf("The target element %d is at index %d of the array", target, index);
    } else {
      printf("The target number you are trying to find does not exist in the array");
    }

    return 0;

}

int binary_srch(const int search_array[], int target, int size) {

    int top, bottom, middle, index, found;
    bottom = 0; // subscript of the initial array element
    top = size - 1; // subscript of the last array element
    found = FALSE;
    
    // while bottom is smaller than top and target is not found, run the if satements
    while (bottom <= top && found == FALSE) {
        middle = (bottom + top) / 2;
        if (search_array[middle] == target) {
            found = TRUE;
            index = middle;
        } else if (search_array[middle] > target) {
            top = middle - 1;
        } else {
            bottom = middle + 1;
        }
    }

    // if found == 1, return index number, else return -1
    if (found == TRUE)
        return index;
    else
        return NOT_FOUND;

}
