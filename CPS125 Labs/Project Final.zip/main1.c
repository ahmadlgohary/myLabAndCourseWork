#include <stdio.h>
#define MINUTE 60 /* Number of minutes in an hour*/
#define M_LITER 1000
#define SENTINEL 5

int get_problem(void);
void get_rate_drop_factor(double *, double *);
void get_kg_rate_conc(double *, double *, double *);
void get_units_conc(double *, double *);
double get_n_hours(double);
double fig_drops_min(double, double);
double fig_ml_hr(double);
double by_weight(double, double, double);
double by_units(double, double);

int main(void){
    int value; /* option chosen*/
    double answer;  /*returns value of function*/
    double ml_hour; /* rate in ml/hr*/
    double drops_ml; /* tubing factor in drops/ml*/
    double mg_kg_hour; /* rate in mg/kg/hr*/
    double pat_weight; /* patient's weight in kg*/
    double mg_ml; /* concentration in mg/ml*/
    double units_hour; /* rate in units/hr*/
    double units_ml; /* concentration in units/ml*/
    double num_hours; /* number of hours for 1 L to be delivered*/

    //Initiates the menu and assigns user input to the variable value.
    value = get_problem();

    //While loop that continues until the user enters the sentinel (5).
    while(value!=SENTINEL){
    switch(value){
        case(1):
            //Option 1 gets the rate and tubing factor and returns the intra rate in drops/min.
            get_rate_drop_factor(&ml_hour,&drops_ml);
            answer=fig_drops_min(ml_hour,drops_ml);
            printf("The intra rate in drops/min is: %.2lf\n\n",answer);
            break;
        case(2):
            //Option 2 gets the number of hours and returns the intra rate in ml/hr.
            answer=fig_ml_hr(get_n_hours(num_hours));
            printf("The intra rate in ml/hr is %.2lf\n\n",answer);
            break;
        case(3):
            /*Option 3 prompts the user to input the rate in mg/kg/hr, the patient's weight in kg,
            and concentration in mg/ml and returns the intra rate in ml/hr*/
            get_kg_rate_conc(&mg_kg_hour,&pat_weight,&mg_ml);
            answer=by_weight(mg_kg_hour,pat_weight,mg_ml);
            printf("The intra rate in mg/ml/hr is %.2lf\n\n",answer);
            break;
        case(4):
            /*Option 4 prompts user to input rate in units/hr and concentration in units/ml
            and returns intra rate in ml/hr.*/
            get_units_conc(&units_hour,&units_ml);
            answer=by_units(units_hour,units_ml);
            printf("The intra rate in ml/hr is %.2lf\n\n",answer);
            break;
        default:
            printf("Wrong input.\n");
        }
        //Continues to ask the user for input until it enters the sentinel.
        value=get_problem();
    }
}

/* function displays menu and gets user's input*/
int get_problem(void){
  /* TO DO */ /* 0.5 mark */
    int menu_number;
    printf("GIVEN A MEDICAl ORDER IN \t\t\t CALCULATE RATE IN\n");
    printf("(1)ml/hr & tubing drop factor\t\t\t\tdrops/min\n");
    printf("(2) L for n hour\t\t\t\t\tml/hr\n");
    printf("(3)mg/kg/hr & tubing drop factor\t\t\tml/hr\n");
    printf("(4) units/hr & concentration in units/ml\t\tml/hr\n(5)QUIT\n\n");
    scanf("%d",&menu_number);
return(menu_number);
}

/* function prompts the user to enter rate and tubing's drop factor then returns values through output
parameters
*/
void get_rate_drop_factor(double *ml_hour, double *drops_ml) {
    /* TO DO */ /* 1 mark */
    printf("Enter the rate (mL/hr): ");
    scanf("%lf",ml_hour);
    printf("Enter the tubing's drop factor (drops/ml): ");
    scanf("%lf",drops_ml);
}

/* function to get the number of hours */
double get_n_hours(double num_hours){
    /* TO DO */ /* 0.5 mark */
    printf("Enter Num. of Hours: ");
    scanf("%lf", &num_hours);
    return(num_hours);
}

/* function prompts for rate, patient's weight, and concentration then returns values through output
parameters
*/
void get_kg_rate_conc(double *mg_kg_hour, double *pat_weight, double *mg_ml){
    /* TO DO */ /* 1 mark */
    printf("Enter The Required Rate (mg/kg/hour): ");
    scanf("%lf",mg_kg_hour);
    printf("Patients Weight in kg: ");
    scanf("%lf", pat_weight);
    printf("Enter The Required Concentration(mg/ml): ");
    scanf("%lf", mg_ml);
}

/* function prompts for rate and concentration then returns values through output parameters */
void get_units_conc(double *units_hour, double *units_ml){
    /* TO DO */ /* 1 mark */
    printf("Enter the rate (unit/hr): ");
    scanf("%lf",units_hour); //The variable is a pointer and therefore no need for & operand
    printf("Great! Now enter the concentration(units/ml): ");
    scanf("%lf",units_ml);
}

/* function takes as input rate and concentration then returns as its value the
result of dividing their product by MINUTE */
double fig_drops_min(double ml_hour, double drops_ml) {
    /* TO DO */ /* 1 mark */
    return (ml_hour*drops_ml)/MINUTE;
}
/* function takes as input num_hours and returns as its value the quotient of * 1000 and num_hours */
double fig_ml_hr(double num_hours){
    /* TO DO */ /* 1 mark */
    return M_LITER/num_hours;
}
/* function takes 3 inputs and returns as its value the product of rate and patient's weight divided by
concentration */
double by_weight(double mg_kg_hr, double pat_weight, double mg_ml){
    /* TO DO */ /* 1 mark */
    return (mg_kg_hr*pat_weight)/mg_ml;
}
/* function takes 2 inputs and returns as its value the quotient of units_hr and units_ml*/
double by_units(double units_hour, double units_ml){
    /* TO DO */ /* 1 mark */
    return (units_hour/units_ml);
}
