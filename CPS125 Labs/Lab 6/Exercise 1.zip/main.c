#include <stdio.h>

  int f1(int x){
   x/=10;
   return (x);
  }

  int f2(int x){
   x=x%10;
   return (x);
  }

  int f3(int x)
  { int *ptr, a;
   ptr = &x;
   a = *ptr+4;
   printf("The value of x at this address is %d.\nx plus 4 is %d\n", *ptr, a);
   return (x);
  }

int main(void) {
  int x, y, z, a;
do {
  printf("enter a number between 10 and 99\n");
  scanf("%d",&x);
  }
while (x<10 || x>99);
  y=x;
  z=x;
  x=f1(x);
  y=f2(y);
  printf("There is %d tens in your number.\nAnd the remainder is %d.\n",x, y);
  z=f3(z);
  return 0;
}