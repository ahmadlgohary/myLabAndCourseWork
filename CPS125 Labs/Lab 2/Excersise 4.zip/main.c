#include <stdio.h>

int main(void) {
float rn;
printf("no we cannot\n");
printf("enter a real number\n");
scanf("%f", &rn);
rn = rn/1000;
printf("your number is %f", rn);
return(0);
}