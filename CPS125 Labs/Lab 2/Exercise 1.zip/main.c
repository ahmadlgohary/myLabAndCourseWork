#include <stdio.h>

int main(void) {
printf("This is my first C program\n");
printf(" This\n is\n my\n first\n C\n program\n");

  return 0;
}